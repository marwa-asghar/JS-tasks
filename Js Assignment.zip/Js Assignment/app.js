// // Chapter #1 

// // Q no1 
// alert("hello world");


// // Q no 2 
// alert("Error! Please enter a valid password.")


// // Q no 3 
// alert("Welcome to JS land...\nHappy Coding!")


// // Qno 4
// alert("Welcome to JS land..")
// window.alert("Happy Coding!\nPrevent this page from creating addinational dialogs.")


// // Q no 5
// console.log("Hello ..I can run JS through my web browser's console")


// // chapter no 2 

// // Q no 1
// var username;


// // Q no 2 
// var myName ="Marwa Asghar";
// document.write(myName)


// // Q no 3
// var message;
// message="Hello world"
// alert(message)


// //  Q no 4
//  var name=prompt("Enter you name: ")
//  var age = prompt("Enter your age: ")
// var course=prompt("Enter your course name")
// alert(name)
// alert(age+" year old")
// alert(course)


// // Q no 5
//  var food="pizza"
//  alert(food+"\n"+food.substring(0, food.length - 1)+"\n"+food.substring(0, food.length - 2)+"\n"+food.substring(0, food.length - 3)+"\n"+food.substring(0, food.length - 4)+"\n"+food.substring(0, food.length - 5))
 

// // Q no 6 
// var email = "marwam.asghar@gmail.com"
// alert("My email address is "+email)


// // Q no 7 
// var book ="A smarter way to learn JavaScript"
// alert("I am trying to learn from the Book "+book)


// // Q no 8 
// document.write("Yah! I can write HTML content through JavaScript")

// // Q no 9
// alert("“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”")


// // Chapter no 3 

// // Q no 1 
// var age =22
// alert("I am "+age+" year old")


// // Q no 2
// var visitedNo = 15
// alert("you have visited this website "+visitedNo+" times")


// // Q no 3 
// var birthYear = 1999
// alert("My birth year is "+birthYear+"\nData type of my declared variable is number ")


// // Q no 4 
// var visitorName = "marwa"
// var product = "T-Shirt"
// var productQuantity= 5
// var website = "www.XYZClothingStore.com"
// alert(visitorName+" ordered "+ productQuantity +" "+product+" on "+website)


// // Chapter no 4

// // Q no 1
// var name , fname , rollNum;


// // Q no 2
// // Legal variable
// var name1;
// var First_Name;
// var $num;
// var courseName;
// var _$Name;
// // illegal variables
// var First Name;
// var 1name;
// var %Num;
// var course-name;
// var name&;

// // chapter no 5 

// // Q no1 
// var num1 = +prompt("Enter a number: ");
// var num2 = +prompt("Enter another number: ");
// var ans = num1 + num2 ;
// document.write("Sum of "+num1+" and "+num2+ " is "+ans);

// // Q no 2
// var num1 = +prompt("Enter a number: ");
// var num2 = +prompt("Enter another number: ");

// var sub = num1 - num2 ;
// var mult = num1 * num2 ;
// var division = num1 / num2 ;
// var mod = num1 % num2 ;

// document.write("<br>Subtraction of "+num1+" and "+num2+ " is "+sub);
// document.write("<br>Multiplication of "+num1+" and "+num2+ " is "+mult);
// document.write("<br>Division of "+num1+" and "+num2+ " is "+division);
// document.write("<br>Modulus of "+num1+" and "+num2+ " is "+mod);


// // Q no 3
// var x ;
// document.write("Valure after variable declaration is: "+x);
// x = 5 ;
// document.write("<br>Initial value is: "+x);
// ++x;
// document.write("<br>Value after incriment is: "+x);
// x = x + 7;
// document.write("<br>Value after Addition is: "+x);
// --x;
// document.write("<br>Value after decriment is: "+x);
// x = x % 3 ;
// document.write("<br>The reminder is: "+x);


// // Q no 4 
// var ticketPrice = 600;
// var n = 5 ;
//  var cost = n * ticketPrice ;
// document.write("Cost of buying "+n+" tickets to a movie is "+cost+ " PKR")


// // Q no 5 
// var num = 5;
// document.write("Table of "+num+"<br>")
// for(i = 1 ; i <= 10 ; i++){
//     document.write(num +" * " +i+ " = " +num*i)
//     document.write("<br>");
// }


// // Q no 6 
// var C = 30 ;
// var F =(C * 9/5) + 32 ;
// document.write("The "+C+"C is "+F+ " in Fahrenhiet<br>");
// var f = 75;
// c = ( f - 32 ) * 5 / 9 ;
// document.write("The "+f+"F is "+c+ " in Celcius");


// //Q no 7
// var item1Price = 700;
// var item2Price = 100;
// var item1Quantity = 3 ;
// var item2Quantity = 1 ;
// var shCharges = 100;
// var totalPrice =( item1Price * item1Quantity ) + (item2Price * item2Quantity ) + shCharges ;
// document.write("Price of item 1 is "+item1Price)
// document.write("<br> Price of item 2 is " +item2Price+"<br> Quantity of item 1 is "+item1Quantity+"<br>Quantity of item 2 is "+item2Quantity+"<br><br>Total cost of your shopping is "+totalPrice);


// // Q no 8
// var obtainedMarks = 900 ;
// var totalMarks = 1000 ;
// var per = obtainedMarks /totalMarks * 100 ;
// document.write("Obtained Marks: "+obtainedMarks+"<br>Total Marks: "+totalMarks+"<br>Percentage: "+per+"%");


// // Q no 9
// var dollars = 10;
// var riyals = 25 ;
// var Total = 10 * 104.80 + 25 * 28;
// document.write("Total currency in PKR: "+Total);

// //Q no 10
// var num = 5 ;
// var calc = ((num + 5) * 10) / 2;
// //document.write("Calculated value is: "+ calc);
// document.wite("Calculated value is: "+ calc);


// // Q no 11
// var birthYear = 1984;
// var futureYear  = 2012;
// var age  = futureYear - birthYear;
// document.write("They are either " + age + " or " + (age - 1)+" years old");


// // Q no 12
// var radius = 20 ;
// var circumfernece  = 2 * 3.142 * radius ;
// var area = 3.142 * radius * radius ;
// document.write("Radius of the circle is: "+radius+"<br>Circumference of the circle is: "+circumfernece+"<br>Area of the circle is: "+area);


// // Q no 13
// var snack = "chocolates";
// var age = 22;
// var maxAge = 60;
// var snackPerDay = 5;
// var requiredSnacks = (maxAge - age) * snackPerDay;
// document.write ("You will need "+requiredSnacks+" "+snack+" to last you until the ripe old age of "+maxAge );


// // Chapter no 6 - 9
// // q no 1
// var a = 10;
// document.write("The value of a is: "+a+"<br>.................................");
// a = ++a;
// document.write("<br><br>The value of ++a is: "+a);
// document.write("<br>Now the value of a is: "+a);

// document.write("<br><br>The value of a++ is: "+a++);
// document.write("<br>Now the value of a is: "+a);
// a = --a;
// document.write("<br><br>The value of --a is: "+a);
// document.write("<br>Now the value of a is: "+a);

// document.write("<br><br>The value of a-- is: "+a--)
// document.write("<br>Now the value of a is: "+a);


// // Q no 2
// var a = 2, b = 1;
// var result = --a - --b + ++b + b--;
// //            1  -  0  +  1  + 1 = 3
// document.write("<br>a is: "+a);
// document.write("<br>b is: "+b);
// document.write("<br>result is: "+result);


// Q no 3
var name = prompt("What is your name? ");
alert('Have a nice day '+name+"! :)");


// // Q no 4
// // Q no 5
// var num = +prompt("Enter to number: ");
// if(num  == ""){
//     for(i=1 ; i <= 10 ; i++ ){
//         console.log("5 * "+ i + " = " + 5*i);
//     }
// }
// else{
//     for(i=1 ; i <= 10 ; i++ ){
//     console.log(num + " * " + i + " = " + num*i );
//     }
// }


// // Q no 6
// var sub1 = prompt("Enter the name of first subject: ");
// var sub2 = prompt("Enter the name of Second subject: ");
// var sub3 = prompt("Enter the name of Third subject: ");
// var tmarks = 100;
// var Sub1Marks = +prompt("Enter the obtained marks of " + sub1);
// var Sub2Marks = +prompt("Enter the obtained marks of " + sub2);
// var Sub3Marks = +prompt("Enter the obtained marks of " + sub3);
// var totalObtainedMarks = Sub1Marks + Sub2Marks + Sub3Marks ;
// var totalMarks = 300;
// var Percentage = totalObtainedMarks / totalMarks * 100 ;
// document.write("Subject \xa0\xa0\xa0 Total Marks \xa0\xa0\xa0 Obained Marks \xa0\xa0\xa0 Percentage<br>"+sub1+
// "\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0 100\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0"+Sub1Marks+
// "\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0"+Sub1Marks/100 *100+" %<br>");
// document.write(sub2+"\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0 100 \xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0"+Sub2Marks+
// "\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0"+Sub2Marks/100*100+" %<br>");
// document.write(sub3+"\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0 100 \xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0"+Sub3Marks+
// "\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0"+Sub3Marks/100*100+" %<br>");
// document.write("\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0"+totalMarks+
// "\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0"+totalObtainedMarks+
// "\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0"+Percentage+" %");


// // Chapter n0 9 - 10
// // Q no 1
// var city = prompt("Enter your city name: ");
// if(city === 'karachi'){
//     alert("Welcome to the city of lights!");
// }
// else{
//     alert("Your city is: "+city);
// }


// // Q no 2
// var gender = prompt("Enter your gender: ");
// if (gender === 'male'){
//     alert("Good Morning Sir");
// }
// else if (gender === 'female'){
//     alert("Good Morning Ma'am");
// }
// else{
//     alert("Invalid Input")
// }


// // Q no 3
// var color = prompt("Enter the color of traffic light signals: ");
// if(color === 'red'){
//     alert("Must Stop");
// }
// else if(color === 'yellow'){
//     alert("Ready to move");
// }
// else if (color === 'green'){
//     alert("Move now");
// }
// else{
//     alert("Invalid input");
// }
    

// // Q no 4
// var fuelAmount = prompt("Enter the remaining fuel in your car: ");
// if(fuelAmount < 0.25){
//     alert("Please refill the fuel in your car");
// }
// else{
//     alert("Its enough");
// }


// //  Q no 5 a 
// var  a = 4;
// if (++a === 5){
// alert("given condition for variable a is true")
// }
// //  Q no 5 b 
// var b = 82;
// if (b++ === 83){
// alert("given condition for variable b is true");
// }
// else{
//     alert("Its false");
// }
// // Q no 5 c
//  var c = 12;
// if (c++ === 13){
//     alert("condition 1 is true");
//     }
// if (c === 13){
//     alert("condition 2 is true");
//     }
// if (++c < 14){
//     alert("condition 3 is true");
//     }
// if(c === 14){
//     alert("condition 4 is true");
//     }
    
// // Q no 5 d
// var materialCost = 20000;
// var laborCost = 2000;
// var totalCost = materialCost + laborCost;
// if (totalCost === laborCost + materialCost){
// alert("The cost equals");
// }
// // e
// if(true){
//     alert("true");
//  } 
// if(false){
//     alert("false");
// }
// // f 
// if("car" < "cat"){
//     alert("car is smaller than cat");
//     }


// //  Q no 6
// var eng = +prompt("Enter the marks of English subject");
// var urdu = +prompt("Enter the marks of Urdu subject");
// var math= +prompt("Enter the marks of Math subject");
// var obtainedMarks = eng + math + urdu ;
// var totalMarks = 300;
// var Percentage = obtainedMarks / totalMarks * 100 ;
// if(Percentage <= 100 && Percentage >= 80){
//     document.write("<h1>Mark sheet</h1><br><br>Total Marks: "+totalMarks+"<br>Marks Obtained: "+obtainedMarks+
//     "<br>Percentage: "+Percentage+" % <br>Grade : A+ <br>Remarks: Excellent");
// }
// else if(Percentage >=70 && Percentage < 80){
//     document.write("<h1>Mark sheet</h1><br><br>Total Marks: "+totalMarks+"<br>Marks Obtained: "+obtainedMarks+
//     "<br>Percentage: "+Percentage+" % <br>Grade : A <br>Remarks: Good");
// }
// else if(Percentage >=60 && Percentage < 70){
//     document.write("<h1>Mark sheet</h1><br><br>Total Marks: "+totalMarks+"<br>Marks Obtained: "+obtainedMarks+
//     "<br>Percentage: "+Percentage+" % <br>Grade : B <br>Remarks: You need improvement");
// }
// if(Percentage < 60 ){
//     document.write("<h1>Mark sheet</h1><br><br>Total Marks: "+totalMarks+"<br>Marks Obtained: "+obtainedMarks+
//     "<br>Percentage: "+Percentage+" % <br>Grade : Fail <br>Remarks: Sorry!");
// }


// // Q no 7 
// var secretNum = 6 ;
// var guess = +prompt("Guess the secret number: ");
// if(secretNum === guess){
//     alert('Bingo! Correct answer');
// }
// else if(secretNum === guess+1){
//     alert('Close enough to the correct answer');
// }
// else{
//     alert("try again!");
// }


// // Q no 8 
// var number = +prompt("Enter the number");
// if(number%3 == 0){
//     alert("Number is divisible by 3");
// }
// else{
//     alert("Number is not divisible by 3");
// }


// // Q no 9
// var number = +prompt("Enter a number: ");
// if(number%2 == 0){
//     alert(number+" is an even number");
// }
// else{
//     alert(number+" is an odd number");
// }


// // Q no 10
// var temperature = +prompt("Enter the temperature");
// if(temperature>40){
//     alert("Its too hot outside");
// }
// else if(temperature>30 && temperature<=40){
//     alert("The Weather today is Normal");
// }
// else if(temperature>20 && temperature<=30){
//     alert("Today's Weather is cool")
// }
// else if(temperature>10 && temperature<=20){
//     alert("OMG! Today's Weather is so cool")
// }


// // Q no 11
// var num1 = +prompt("Enter the first number: ");
// var num2 = +prompt("Enter the second numebr:");
// var operator = prompt("Enter the operator");
// if(operator == '+'){
//     document.write(num1+" + "+num2+" = "+num1+num2);
// }
// else if(operator == '-'){
//     document.write(num1+" - "+num2+" = "+num1-num2);
// }
// else if(operator == '*'){
//     document.write(num1+" * "+num2+" = "+num1*num2);
// }
// else if(operator == '/'){
//     document.write(num1+" / "+num2+" = "+num1/num2);
// }
// else if(operator == '%'){
//     document.write(num1+" % "+num2+" = "+num1%num2);
// }
// else{
//     alert("invalid input!");
// }


// // Chapter no 12 - 13
// // Q no 1
// var char = prompt("Enter a character or a sring or a number: ");
// if(char >= 65 && char <= 90){
//     alert("Capital letter")
// }
// else if(char >= 97 && char <= 122){
//     alert("Small letter")
// }
// else if(char >= 48 && char <= 57){
//     alert("Digit")
// }
// else{
//     alert("Special character")
//}


// // Q  no 2
// var int1 = +prompt("Enter a number:");
// var int2 = +prompt("Enter another number:");
// if(int1>int2){
//     alert(int1+" > "+ int2);
// }
// else if(int1<int2){
//     alert(int1+" < "+ int2);
// }
// else if(int1==int2){
//     alert(int1+" = "+ int2);
// }


// // Q no 3
// var num = +prompt("Enter a number :");
// if(num<0){
//     alert("Number is negative");
// }
// else if(num>0){
//     alert("Number is positive");
// }
// else if(num==0){
//     alert("Number is Zero!");
// }

// // Q no 4
// var vowel = prompt("Enter a vowel letter: ");
// if(vowel == 'a' || vowel == 'e' || vowel == 'i' || vowel == 'o' || vowel == 'u'){
//     alert("Yes, it is a vowel letter");
// }
// else{
//     alert("false! it is not a vowel letter");
// }


// // Q no 5 
// var password = "MyPassword";
// var checkPassword = prompt("Enter your password");
// if(checkPassword == ''){
//     alert("Please enter your password");
// }
// else if (checkPassword === password){
//     alert("Correct! The password you entered matches the original password");
// }
// else{
//     alert("Invalid password!");
// }


// // Q no 6
// var greeting;
// var hour = 13;
// if (hour < 18) {
//     greeting = "Good day";
//     alert(greeting);
// }
// else {
//     greeting = "Good evening";
//     alert(greeting);
// }


// Q no 7
// var time = 1900;
// if(time >= 0000 && time < 1200){
//     alert("Good Morning!");
// }
// else if(time >= 1200 && time < 1700 ){
//     alert("Good Afternoon!");
// }
// else if(time >= 1700 && time < 2100){
//     alert("Good Evening!");
// }
// else if(Time >= 2100 && time <= 2359){
//     alert("Good Night!");
// }


// // Chapter no 14 - 16
// // Q no 1
//  var studentName = [];
 
// //  Q no 2
// var stuNames = new Array();

// // Q no 3
// var arrAnimal = ['cat','lion','tiger','dog','wolf','monkey'];

// // Q no 4
// var numArray = [2,4,6,8,10,12,14,16,18,20];

// // Q no 5
// var booleanArray = [true , false];

// // Q no 6
// var mixedArray = [1, 'marwa' ,true ];

// // Q no 7
// var edu = ['SSC','HSC','BSC','BS','B.COM','MS','M.Phil','PhD'];
// document.write("<h1>Qualifications</h1><br>");

// for(count=0; count<edu.length ; count++){
//     document.write((count+1)+") "+edu[count]+"<br>");
// }


// // Q no 8
// var studentArray = ['Marwa' , 'Hira' , 'Hassanta'];
// var studentMarks = [460 , 395 , 470];
// var marks = 500 ;
// for(i = 0 ; i < studentArray.length ; i++){
//         var Percentage = studentMarks[i]/marks * 100;
//         document.write("Score of "+studentArray[i]+" is "+studentMarks[i]+". percentage: "+Percentage+"<br>");
    
// }


// // Q no 9
// var colors = ['Blue' , 'Pink' , 'Red' ];
// document.write(colors);
// var add = prompt("Enter the color name you want to add to the beginning");
// colors.unshift(add);
// document.write("<br>"+colors);
// var addToLast = prompt("Enter the color name you want to add to the end");
// colors.push(addToLast);
// document.write("<br>"+colors);
// var addMore1 = prompt("Add more colors to begining");
// var addMore2 = prompt("Add more colors to begining");
// colors.unshift(addMore1,addMore2);
// document.write("<br>"+colors);
// colors.shift();
// document.write("<br>"+colors);
// colors.pop();
// document.write("<br>"+colors);
// var index = prompt("At which index you want to add Color?");
// var addMore3 = prompt("Enter the color name you want to add at "+index);
// colors.splice(index,0,addMore3);
// document.write("<br>"+colors);
// var deletingIndex = prompt("At which Index you want to delete color?");
// var colorNo = prompt("How many you want to delete?");
// colors.splice(deletingIndex,colorNo);
// document.write("<br>"+colors);


// // Q no 10
// var studentScore = [320 , 230 , 480 , 120]
// document.write("Unsorted List: "+studentScore);
// studentScore.sort();
// document.write("<br>Sorted List: "+studentScore);


// // Q no 11
// var cities = ['Karachi' , 'Lahore' , 'Islamabad' , 'Quetta' , 'Peshawar'];
// document.write('Cities list: '+cities);
// var selectedCities = cities.slice(2,5);
// document.write('<br>Selected Cities List: '+selectedCities);


// // Q no 12 
// var arr = ['This' , 'is' , 'my' , 'cat'];
// document.write('Array: '+arr);
// var string = arr.join(" ");
// document.write('<br>String: '+string);


// // Q no 13
// var devices = ['Keyboard' , 'Mouse' , 'Printer' , 'Monitor'];
// document.write("Devices: <br>"+devices+'<br>')
// for(i = 0 ; i < devices.length ; i++){
//     document.write("<br>Out:<br>"+devices[i])
// }


// // Q no 14
// var devices = ['Keyboard' , 'Mouse' , 'Printer' , 'Monitor'];
// document.write("Devices: <br>"+devices+'<br>')
// var reverseDevices = devices.reverse();
// for(i = 0 ; i < devices.length ; i++){
//     document.write("<br>Out:<br>"+reverseDevices[i])
// }


// // Q no 15
// var phoneManu = ['Apple' , 'Samsung' , 'Motorola' ,'Nokia' ,  'Sony' , 'Haier'] 
// document.write("Phone manufacturers: <select ><option></option><option>Apple</option><option>Samsung</option><option>Motorola</option><option>Nokia</option><option>Sony</option><option>Hier</option></select>"); 


// // Chapter no 17 - 20
// // Q no 1
// var arrFirst = [[1 , 2] , [2 , 3] , [3 , 4] , [4 , 5]];


// // Q no 2
// var multiArr = [[0 , 1 , 2 , 3] , [1 , 0 , 1 , 2] , [2 , 1 , 0 , 1]];
// var arr1 = multiArr[0].join(" ");
// var arr2 = multiArr[1].join(" ");
// var arr3 = multiArr[2].join(" ");
// document.write(arr1+"<br>"+arr2+"<br>"+arr3);

// // Q no 3
// for(i = 1 ; i <=10 ; i++ ){
//     document.write(i+"<br>");
// }


// // Q no 4
// var tableNum = +prompt("Enter a number to show its multiplication: ");
// var len = +prompt("Enter length of multiplication table: ");
// document.write("Multiplication of Table "+tableNum+"<br>");
// document.write("Length "+len+"<br><br>");
// for(count = 0 ; count < len ; count++){
//     document.write(tableNum+" * "+(count+1)+" = "+tableNum*(count+1)+"<br>");
// }


// // Q no 5
// var fruit = ['Apple' , 'Mango' , 'Banana' , 'Orange ' , 'Strawberry']
// for (let i = 0; i < fruit.length; i++) {
//     document.write(fruit[i]+"<br>")
// }
// document.write("<br><br>")
// for (let index = 0; index < fruit.length; index++) {
//     document.write("Element at Index "+index+" is "+ fruit[index]+"<br>");
// }


// // Q no 6
// document.write("<h3>Counting: </h3>");
// for (let index = 0; index <15; index++) {
//     document.write((index+1)+" ");
// }
// var arr  = [1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10]
// document.write("<h3>Reverse counting:</h3> ");
// for (var i = arr.length-1 ; i >= 0 ; i-- ) {
//    document.write(arr[i]+" ");
// }
// document.write("<h3>Even counting:</h3> ");
// for(var i = 0 ; i <= 20 ; i++){
//     document.write(i+" ");
//      ++i;
// }
// document.write("<h3>Odd counting:</h3> ");
// for(var i = 1 ; i <= 19 ; i++){
//     document.write(i+" ");
//      ++i;
// }
// document.write("<h3>Series:</h3> ");
// for(var i = 2 ; i <= 20 ; i++){
//     document.write(i+"k ");
//      ++i;
// }


// // Q no 7
// var A = ['cake' , 'apple pie' , 'cookies' , 'chips' , 'patties'];
// var search = prompt("Welcome to ABC bakery . What do you want to order sir/ma'am?");
// for(count = 0 ; count < A.length ; count++){
//     if(search == A[count]){
//         document.write(search+" is <b>available</b> at index "+count+" in our bakery.");
//         break;
//     }
//     else {
//         document.write("We are sorry. "+search+" is <b>not available </b>in our bakery.<br>")
//     }
// }


// // Q no 8
// var array = [24 , 53, 78, 91, 12];
// var largest= 0;

// for (i=0; i<=largest;i++){
//     if (array[i]>largest) {
//         var largest=array[i];
//     }
// }
// document.write("The largest number is "+largest);
  

// // Q no 9
// var array = [24 , 53, 78, 91, 12];
// var minvalue = array[0]; 
// for (var i = 0; i < array.length; i++) {
//     if(array[i]<minvalue)
//     {
//         minvalue = array[i];
//     }

// }
//   document.write("The smallest value is "+minvalue);


// // Q no 10
// document.write("1 ");
// for(i = 1 ; i <= 20 ; i++){
//     document.write(i*5 +" ");
// }
  